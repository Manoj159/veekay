

<style>
    .btn{
         background: linear-gradient(145deg, rgba(20,201,148,0.8),rgb(6,135,167)) !important;
        color: white !important;
        border: none !important;
        border-radius: 20px !important;
    }
    .php-email-form{
        border: none !important;
        box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
    }
    .contact .info{
        border: none !important;
        box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
    }
    
    
    .card_bg{
         background: linear-gradient(145deg, rgba(20,201,148,0.8),rgb(6,135,167)) !important;
        color: white !important;
        border: none !important;
        border-radius: 20px !important;
        box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
    }
    
</style>
<main id="contact" class="py-5 contact-us-page blogs-page">
	
	<section id="contact" class="contact">
      <div class="container">

      <nav aria-label="breadcrumb" class="mt-3">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Blogs</li>
          </ol>
        </nav>
       
        <div class="section-title">
          <h3 class="text-white text-uppercase">Happyeasy Blogs</h3>
        </div>

        <div class="row">

           <?php
                foreach($blog as $b){
                    $titleUrl = strtolower(str_replace(" ","-",$b->title));
            ?>
            <div class="col-sm-4 mb-4">
                <div class="blog-list card">
                  <a href="<?= base_url("blogs/read/$titleUrl"); ?>"> 
                  <div class="img-part">      
                    <img src="<?= base_url($b->image); ?>" width="100%" alt="<?= $b->meta_title; ?>"/>
                  </div>      
                  <div class="card-detail">
                    <h4><?= $b->title; ?></h4>
                    <span class="text-primary">Read More...</span> 
                    </div>
                  </a>
                </div>
            </div>
           <?php  }  ?>
          
        </div>

      </div>
    </section>

</main>