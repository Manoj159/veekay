<section></section>

<style>
    .btn{
         background: linear-gradient(145deg, rgba(20,201,148,0.8),rgb(6,135,167)) !important;
        color: white !important;
        border: none !important;
        border-radius: 20px !important;
    }
    .php-email-form{
        border: none !important;
        box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
    }
    .contact .info{
        border: none !important;
        box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
    }
    
    
    .card_bg{
         background: linear-gradient(145deg, rgba(20,201,148,0.8),rgb(6,135,167)) !important;
        color: white !important;
        border: none !important;
        border-radius: 20px !important;
        box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
    }
    
</style>
<main id="contact" class="py-5 contact-us-page">
	
	<section id="contact" class="contact">
      <div class="container">
<nav aria-label="breadcrumb" class="mt-3">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Contact Us</li>
          </ol>
        </nav>
        
        <div class="section-title">
          <h3 class="text-white text-uppercase">Contact Us</h3>
        </div>

        <div class="row">

            <div class="col-sm-4">
              <div class="card text-center p-4 card_bg card-upper">
                <i class="bi bi-geo-alt"></i>
                <h4>Address:</h4>
                <p>SF 32, 14th Avenue High Street Commercial Market, Gaur City 2, Greater Noida, Uttar Pradesh 201009</p>
              </div>
            </div>

            <div class="col-sm-4">
              <div class="card text-center p-4 card_bg card-upper">
                <i class="bi bi-envelope"></i>
                <h4>Email Address:</h4>
                <p>hello@happyeasyrides.com</p>
              </div>
            </div>

            <div class="col-sm-4">
              <div class="card text-center p-4 card_bg card-upper">
                <i class="bi bi-phone"></i>
                <h4>Contact Number:</h4>
                <p>+91-9289044919</p>
                <p>+91 97178 14443</p>
                <p>+91-<?= $this->db->get_where('settings', array('type'=>'phone'))->row()->description; ?></p>
              </div>
            </div>

          <div class="col-lg-5 d-flex align-items-stretch mt-3" id="map">
            <div class="info card">
              <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3502.2989092770645!2d77.41471620075305!3d28.62080223233618!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390cefda72a89605%3A0x2994cde6af5abdca!2sHappyeasyrides%20self%20drive%20car%20rentals!5e0!3m2!1sen!2sin!4v1651918329538!5m2!1sen!2sin" frameborder="0" style="border:0; width: 100%; height: 100%;" allowfullscreen></iframe>
            </div>

          </div>

          <div class="col-lg-7 d-flex align-items-stretch mt-3">
            <form action="" method="post" role="form" class="php-email-form card">
              
              <div class="row">
                <div class="form-group col-md-6">
                  <label for="name">First Name</label>
                  <input type="text" name="firstname" class="form-control" id="firstname" required>
                </div>
                <div class="form-group col-md-6">
                  <label for="name">Last Name</label>
                  <input type="text" class="form-control" name="lastname" id="lastname" required>
                </div>
              </div>
              
              <div class="row">
                <div class="form-group col-md-6">
                  <label for="name">Your Contact</label>
                  <input type="number" name="contact" class="form-control" id="contact" required>
                </div>
                <div class="form-group col-md-6">
                  <label for="name">Your Email</label>
                  <input type="email" class="form-control" name="email" id="email" required>
                </div>
              </div>
              <div class="form-group">
                <label for="name">Message</label>
                <textarea class="form-control" name="message" rows="5" required></textarea>
              </div>
              <!-- <div class="my-3">
                <div class="loading">Loading</div>
                <div class="error-message"></div>
                <div class="sent-message">Your message has been sent. Thank you!</div>
              </div> -->
              <div ><button type="submit" class="btn btn-secondary">Send Message</button></div>
            </form>
          </div>

        </div>

      </div>
    </section>

</main>