<section></section>

<style>
    .btn{
         background: linear-gradient(145deg, rgba(20,201,148,0.8),rgb(6,135,167)) !important;
        color: white !important;
        border: none !important;
        border-radius: 20px !important;
    }
    .php-email-form{
        border: none !important;
        box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
    }
    .contact .info{
        border: none !important;
        box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
    }
    
    
    .card_bg{
         background: linear-gradient(145deg, rgba(20,201,148,0.8),rgb(6,135,167)) !important;
        color: white !important;
        border: none !important;
        border-radius: 20px !important;
        box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
    }
    
</style>
<main id="contact" class="py-5 contact-us-page blog-detail">
	
	<section id="contact" class="contact">
      <div class="container">

      <nav aria-label="breadcrumb" class="">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
            <li class="breadcrumb-item"><a href="<?= base_url("blogs"); ?>">Blogs</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?= strtolower(str_replace(" ","-",$blog->title)); ?></li>
          </ol>
        </nav>
       
        <div class="section-title">
          <h3 class="text-white text-uppercase"><?= $blog->title; ?></h3>
        </div>

        <div class="row">

           
            <div class="col-sm-12">
              
              <img src="<?= base_url($blog->image); ?>" width="100%" alt="<?= $blog->meta_title; ?>"/>
              <div class="">
                <p>
                    <?= $blog->description; ?>
                </p>
              </div>
              
            </div>
         
           
          

          

        </div>

      </div>
    </section>

</main>