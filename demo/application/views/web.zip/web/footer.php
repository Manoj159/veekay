

  <!-- ======= Footer ======= -->
  <footer id="footer">

    <div class="footer-top" style="background: #0ca29f">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-contact">
            <h3>Have a</h3>
            
            <h1 style="font-weight:bolder;color:#fff;opacity:0.4;">
                HAPPY <br/>
                EASY <br/>
                <font style="border-bottom:4px solid #fff;">
                RIDE. 
                </font>
            </h1>
            
            <label style="font-weight: bold; color: rgba(0,0,0,0.6)" >A UNIT OF <br/> SHRIARA AUTOMOTIVE LLP</label>
            
            <!--
            <p class="text-justify">
             Happyeasy rides is a brand-new venture, born with the goal to provide more friendly travel options to enthusiasts who love to drive and explore new places. Have satisfied customers for over years now with its smooth and dependable car rental services. Now with all the experience, the company has expanded its outreach to make traveling via roads in India more effortless and exciting.
            </p>
            -->
          </div>
          
          <div class="col-lg-3 col-md-6 footer-links  footer-contact">
            <h3>Serviceable Cities</h3>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="<?= base_url("car-rental-in-chandigarh"); ?>">Chandigarh</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="<?= base_url("car-on-rent-in-delhi"); ?>">Delhi NCR</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="<?= base_url("car-rental-in-amritsar"); ?>">Amritsar</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="<?= base_url("car-on-rental-in-bangalore"); ?>">Bangalore</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="<?= base_url("car-rental-in-rajasthan"); ?>">Rajasthan</a></li>
              
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links  footer-contact">
            <h3>Useful Links</h3>
            <ul>
              <!--<li><i class="bx bx-chevron-right"></i> <a href="#">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Services</a></li>-->
              <li><i class="bx bx-chevron-right"></i> <a href="<?= base_url("terms"); ?>">Terms & Conditions</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="<?= base_url("terms/privacy"); ?>">Privacy policy</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="<?= base_url("terms/refund"); ?>">Cancellation & Refund policy</a></li>
            </ul>
          </div>


          <div class="col-lg-3 col-md-6 footer-links  footer-contact">
            <h3>Contact Us</h3>
            <div class="social-links mt-3">
              <a href="<?= $this->db->get_where('social_links', array('id'=>5))->row()->link; ?>" class="twitter"><i class="bx bxl-twitter"></i></a>
              <a href="<?= $this->db->get_where('social_links', array('id'=>1))->row()->link; ?>" class="facebook"><i class="bx bxl-facebook"></i></a>
              <a href="<?= $this->db->get_where('social_links', array('id'=>4))->row()->link; ?>" class="instagram"><i class="bx bxl-youtube"></i></a>
              <a href="<?= $this->db->get_where('social_links', array('id'=>2))->row()->link; ?>" class="google-plus"><i class="bx bxl-instagram"></i></a>
              <a href="<?= $this->db->get_where('social_links', array('id'=>3))->row()->link; ?>" class="linkedin"><i class="bx bxl-linkedin"></i></a>
            </div>
          </div>

        </div>
      </div>
    </div>

  </footer><!-- End Footer -->

  <!-- <div id="preloader"></div> -->
  
  <style>
      .whats{
          position: fixed;
          bottom: 50px;
          right: 4%;
          z-index: 999;
      }
      .whats .btn-primary{
          border-radius: 100% !important;
          height: auto;
          width: 50px;
          padding: 15px;
      }
  </style>
  
  <div class="whats">
      <a href="https://api.whatsapp.com/send/?phone=%2B919289044919&text=Hello, Happy Easy Ride" target="_blank" class="btn btn-primary btn-lg"><i class="bi bi-whatsapp"></i></a>
  </div>
  
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>


  <script src="<?= base_url(); ?>assets/vendor/aos/aos.js"></script>
  <script src="<?= base_url(); ?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?= base_url(); ?>assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="<?= base_url(); ?>assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="<?= base_url(); ?>assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="<?= base_url(); ?>assets/vendor/waypoints/noframework.waypoints.js"></script>
  <!-- <script src="<?= base_url(); ?>assets/vendor/php-email-form/validate.js"></script> -->

  <script src="<?= base_url(); ?>assets/js/jquery.datetimepicker.full.js"></script>

  <!-- Template Main JS File -->
  <script src="<?= base_url(); ?>assets/js/main.js"></script>

  <script type="text/javascript">
      
   $("#find-cars").click(function(e){
        e.preventDefault();
        checkForHours("searchCarForm");
    });
    $("#find-cars2").click(function(e){
        e.preventDefault();
        checkForHours("book-form");
    });
    function checkForHours(form_name){
        const start = $("#start-date").val();
        const end = $("#end-date").val();
        
        $.ajax({
            url: "<?= base_url("Welcome/getHrs/"); ?>",
            data: {end: end, start: start},
            type: "GET",
            success: function(res){
                if(res < 24){
                    swal({
                      title: "Sorry !!",
                      text: "Please select minimum 24 hours of booking duration.",
                      icon: "warning",
                      timer: 3000
                    });      
                }else{
                    $("#"+form_name).submit();
                }
            }
        });
    }
      
   /* $('#dates').hide(); */

    $('#get_city').change(function(e){
        $('.search_btn').show();
        $('#dates').show();
    });


    $('.search_btn').hide();

    $('#start-date').change(async function(e){
        
        let start_date = $(this).val();
        
        await $.ajax({
            url: "<?= base_url("Welcome/format_change") ?>",
            data: {start_date: start_date},
            type: "POST",
            success: function(res){
                start_date = res;
            }
        });
        
        const today_date = "<?= date("m-d-Y") ?>";
        
        var stt = new Date(start_date);
        //var stt = Date.parse(start_date);
        var stt_month = stt.getMonth();
        
        stt = stt.getDate();
        //let stt_m = stt.getMonth();
        
        
        var endt = new Date(today_date);
        var endt_month = endt.getMonth();
        endt = endt.getDate();
        
        //alert(stt+" "+endt);
        // || stt_month > endt_month
        if(stt > endt || stt_month > endt_month){
            removeTimeLimitFromStart();
        }
        else if(start_date!=today_date){
            // isNaN(stt) &&
            removeTimeLimitFromStart();
        }
        else{
            addTimeLimitToStart();
        }
        
        changeEndDate(start_date);
        $('.search_btn').show();
    });
    function removeTimeLimitFromStart(){
        $('#start-date').datetimepicker({
            datepicker:true,
            defaultTime:'<?= date('H:i', time()+4800); ?>',
            format:'d-m-Y H:i',
            formatDate:'d-m-Y H:i',
            minDate:'<?= date('Y-m-d'); ?>',
            minTime: '00:00'
        });
    }
    function addTimeLimitToStart(){
        $('#start-date').datetimepicker({
            datepicker:true,
            defaultTime:'<?= date('H:i', time()+4800); ?>',
            format:'d-m-Y H:i',
            formatDate:'d-m-Y H:i',
            minDate:'<?= date('Y-m-d'); ?>',
            minTime: '<?= date('H:i'); ?>'
        });
        
    }

    $('#end-date').change(function(e){

        $('.search_btn').show();

    });
  </script>


<script src="https://momentjs.com/downloads/moment.js"></script>

  <script>
    /*  jQuery(document).ready(function () {
        jQuery('#start-date').datetimepicker();
        jQuery('#end-date').datetimepicker();
      }); */


      $('#start-date').datetimepicker({
        datepicker:true,
        defaultTime:'<?= date('H:i', time()+4800); ?>',
        format:'d-m-Y H:i',
        formatDate:'d-m-Y H:i',
        minDate:'<?= date('Y-m-d'); ?>',
        minTime: '<?= date('H:i'); ?>'
      });
      
      $('#end-date').datetimepicker({
        datepicker:true,
        defaultTime:'<?= date('H:i', time()+4800); ?>',
        format:'d-m-Y H:i',
        formatDate:'d-m-Y H:i',
        minDate:'<?= date('Y-m-d', strtotime("+1 day")); ?>',
      });
      
      function changeEndDate(start_date){
          $.ajax({
              url: "<?= base_url("Welcome/addHours/"); ?>",
              data: {date: start_date},
              type: "GET",
              success: function(resDate){
                  
                    $('#end-date').datetimepicker({
                       datepicker:true,
                       defaultTime:resDate,
                       format:'d-m-Y H:i',
                       formatDate:'d-m-Y H:i',
                       minDate:'<?= date('Y-m-d', strtotime("+1 day")); ?>',
                       //minTime:resDate
                    });     
              }
          });
      }
      
      /*
      $('#end-date').datetimepicker({
        datepicker:true,
        defaultTime:'<?= date('H:i', time()+18000); ?>',
        format:'d-m-Y H:i',
        formatDate:'d-m-Y H:i',
        minDate: moment().add(1, "days").toDate(),
        minTime: '<?= date('H:i', time()+18000); ?>'
      });
      */

  </script>


<script type="text/javascript">

  $('#carousel-example').on('slide.bs.carousel', function (e) {
    var $e = $(e.relatedTarget);
    var idx = $e.index();
    var itemsPerSlide = 5;
    var totalItems = $('.carousel-item').length;
    if (idx >= totalItems-(itemsPerSlide-1)) {
      var it = itemsPerSlide - (totalItems - idx);
      for (var i=0; i<it; i++) {
        if (e.direction=="left") {
          $('.carousel-item').eq(i).appendTo('.carousel-inner');
        }
        else {
          $('.carousel-item').eq(0).appendTo('.carousel-inner');
        }
      }
    }
  });
</script>


<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<?php if($this->session->flashdata('success_message') != ""): ?>

<script type="text/javascript">
    
swal({
      title: "Thank you!",
      text: "<?= $this->session->flashdata('success_message'); ?>",
      icon: "success",
      button: "Go Back!",
    });

</script>

<?php endif; ?>

<script>
    $(document).on("click", ".copy", function(){
       const a  =  $(this).attr("row");
       const coupon = $("#coupon"+a).val();
       navigator.clipboard.writeText(coupon);
        
        swal({
          title: "Copied",
          text: `${coupon} coupon copied successfully !!`,
          icon: "success",
          timer: 1000
        });
    });
</script>

<?php if($this->session->flashdata('coupon_error') != ""): ?>
<script type="text/javascript">
    swal({
      title: "Oops!",
      text: "<?= $this->session->flashdata('coupon_error'); ?>",
      icon: "error",
      button: "Go Back!",
    });
</script>
<?php endif; ?>





<?php if($this->session->flashdata('error_message') != ""): ?>

<script type="text/javascript">
   
swal({
      title: "Error !",
      text: "<?= $this->session->flashdata('error_message'); ?>",
      icon: "error",
      button: "Go Back!",
    });

</script>

<?php endif; ?>

<script type="text/javascript">
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function (e) {
                $('#blah').attr('src', e.target.result);
            };
            reader.readAsDataURL(input.files[0]);
        }
    }
</script> 

   

</body>

</html>