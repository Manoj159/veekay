<?php 
    error_reporting(1);
 
    $title = "Happy Easy Self Drive Cars Rides";
    $description = $keywords = "";
    if(isset($meta)){ 
         $title = $meta->title;
         $keywords = $meta->keyword;
         $description = $meta->description;
    }
    
?>
<html lang="en">

<head>
  <meta charset="utf-8">

  <meta content="width=device-width, initial-scale=1.0" name="viewport">


  <title><?= $title; ?></title>

  <meta content="<?= $description; ?>" name="description">

  <meta content="<?= $keywords; ?>" name="keywords">
  
  <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-6H07E5PJBD"></script>
<script>
//   window.dataLayer = window.dataLayer || [];
//   function gtag(){dataLayer.push(arguments);}
//   gtag('js', new Date());

//   gtag('config', 'G-6H07E5PJBD');
</script>

  <link href="<?= base_url(); ?>assets/img/he-logo.png" rel="icon">
 
 <!--  <link href="<?= base_url(); ?>assets/img/apple-touch-icon.png" rel="apple-touch-icon"> -->
 
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Jost:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
  
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
  
  <link href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400&display=swap" rel= "stylsheet">
  
  <link href="<?= base_url(); ?>assets/vendor/aos/aos.css" rel="stylesheet">
  
  <link href="<?= base_url(); ?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  
  <link href="<?= base_url(); ?>assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  
  <link href="<?= base_url(); ?>assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  
  <link href="<?= base_url(); ?>assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  
  <link href="<?= base_url(); ?>assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  
  <link href="<?= base_url(); ?>assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <link href="<?= base_url(); ?>assets/css/style.css" rel="stylesheet">

  <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/css/jquery.datetimepicker.min.css"/>

  <script src="https://code.jquery.com/jquery-3.6.0.js"></script>

  <style type="text/css">
    /*@import url('https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400&display=swap');

    body, h1, h2, h3, h4, h5{
      font-family: 'Be Vietnam Pro', sans-serif !important;
    }*/

     @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200&display=swap');

      body, h1, h2, h3, h4, h5, h6, p{
         font-family: 'Poppins', sans-serif !important;
      }

    .city_name
    {
      border-radius: 0;
    }
    .btn-find
    {
      width: 100%;
      background-color: whitesmoke !important;
      text-transform: uppercase;
      border-radius: 0;
    }
    .footer-contact p
    {
      text-align: justify;
      width: 80%;
    }
    .footer-top h3, .footer-top a, .footer-top p
    {
      color: white !important;
    }
    .btn-block{
      width: 100%;
      border-radius: 20px;
    }

    #header
    {
      background: white;
      color: black !important;
      box-shadow: 0 1px 11px #0000001f;
    }
    .nav-link
    {
      color: black !important;
    }
    .getstarted:hover{
      color: white !important;
    }
    #carouselExampleControls .carousel-item img{
      height: 85vh !important;
    }
   
  </style>

</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top bg-white border">
    <div class="container d-flex align-items-center">

      <a href="<?= base_url(); ?>" class="logo me-auto py-2">
        <img alt="happyeasyrides" src="<?= base_url(); ?>assets/img/he-logo.png" />
        <!--<small>A UNIT OF SHRIARA AUTOMOTIVE LLP</small>-->
      </a>
     
      <nav id="navbar" class="navbar">
        <ul> 
          <li><a class="nav-link scrollto" href="<?= base_url(); ?>">Home</a></li>
          <li><a class="nav-link scrollto" href="<?= base_url("about-us"); ?>">About Us</a></li>
          <li><a class="nav-link scrollto" href="<?= base_url("blogs"); ?>">Blogs</a></li>
          <li><a class="nav-link scrollto" href="<?= base_url(); ?>contact">Contact Us</a></li>

          <?php if($this->session->userdata('user_id') == ''){ ?>

            <li><a class="nav-link scrollto" href="<?= base_url(); ?>login"> Login</a></li>

          <?php } ?>

          <!--<li><a class="text-dark scrollto" href="<?= base_url(); ?>">Book Now</a></li>-->


          <?php if($this->session->userdata('user_id') != ''){ ?>

            <li><a class=" text-dark scrollto" href="<?= base_url(); ?>account">My Account</a></li>

            <li><a class=" text-dark scrollto" href="<?= base_url(); ?>signup/logout">Logout</a></li>
            
            <!--<li><a class="getstarted text-dark scrollto" href="<?= base_url(); ?>Signup/logout">Logout</a></li>-->

          <?php } ?>

        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->
