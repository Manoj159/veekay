<?php
    require"slider-form-section.php";
?>

<!--<section class="why-happy-easy-rides" >
   
   <div class="container">
      <div class="row">
         <div class="col-xl-12">
            
            <div class="heading01 text-center">
               <h4>WHY HAPPYEASY RIDES</h4>
            </div>
            
            <div class="row">
               <div class="col-lg-12">
                  <div id="whyhappyeasy" class="carousel slide" data-bs-ride="carousel">
                    
                     <div class="carousel-inner active">
                       <div class="mobile_slides">
                         <div class="why-us-scroll carousel-item active">
                  
                              <div class="item items1 col-md-4 mb-3">
                                  <div class="why-us-row">
                                    <div class="why-us-image">
                                        <img src="<?= base_url(); ?>assets/img/why/fast-delivery.png" alt="" class="img-fluid">
                                    </div>
                                    <div class="why-us-text">
                                        Free home delivery on booking over 72 hours.                        
                                     </div>
                                  </div>
                               </div>
                         </div>
                         <div class="why-us-scroll carousel-item">
                              <div class="item items1 col-md-4 mb-3">
                                  <div class="why-us-row">
                                    <div class="why-us-image">
                                        <img src="<?= base_url(); ?>assets/img/why/mileage.png" alt="" class="img-fluid">
                                    </div>
                                    <div class="why-us-text">
                                        Count memories, no miles-truly unlimited Kms.                        
                                     </div>
                                  </div>
                               </div>
                              </div>
                         <div class="why-us-scroll carousel-item">
                              <div class="item items1 col-md-4 mb-3">
                                  <div class="why-us-row">
                                    <div class="why-us-image">
                                        <img src="<?= base_url(); ?>assets/img/why/cashback.png" alt="" class="img-fluid">
                                    </div>
                                    <div class="why-us-text">
                                        Refund within 24 hours.                        
                                     </div>
                                  </div>
                               </div>
                        </div>
                         <div class="why-us-scroll carousel-item">
                             <div class="item items1 col-md-4 mb-3">
                                  <div class="why-us-row">
                                    <div class="why-us-image">
                                        <img src="<?= base_url(); ?>assets/img/why/customer-support.png" alt="" class="img-fluid">
                                    </div>
                                    <div class="why-us-text">
                                        24 X 7 customer support.                       
                                     </div>
                                  </div>
                               </div>
                         </div>
                         <div class="why-us-scroll carousel-item">
                             <div class="item items1 col-md-4 mb-3">
                                  <div class="why-us-row">
                                    <div class="why-us-image">
                                        <img src="<?= base_url(); ?>assets/img/why/calendar.png" alt="" class="img-fluid">
                                    </div>
                                    <div class="why-us-text">
                                        Paperless booking process                      
                                     </div>
                                  </div>
                               </div>
                         </div>
                         <div class="why-us-scroll carousel-item">
                             <div class="item items1 col-md-4 mb-3">
                                  <div class="why-us-row">
                                    <div class="why-us-image">
                                        <img src="<?= base_url(); ?>assets/img/why/car-wash.png" alt="" class="img-fluid">
                                    </div>
                                    <div class="why-us-text">
                                        Clean & sanitized cars.                      
                                    </div>
                                  </div>
                               </div>
                         </div>
                       </div>
                       <div class="desktop_slides">   
                                        
                         <div class="why-us-scroll carousel-item active">
                  
                           <div class="row">
                              
                              <div class="item items1 col-md-4 mb-3">
                                  <div class="why-us-row">
                                    <div class="why-us-image">
                                        <img src="<?= base_url(); ?>assets/img/why/fast-delivery.png" alt="" class="img-fluid">
                                    </div>
                                    <div class="why-us-text">
                                        Free home delivery on booking over 72 hours.                        
                                     </div>
                                  </div>
                               </div>
                              
                              <div class="item items1 col-md-4 mb-3">
                                  <div class="why-us-row">
                                    <div class="why-us-image">
                                        <img src="<?= base_url(); ?>assets/img/why/mileage.png" alt="" class="img-fluid">
                                    </div>
                                    <div class="why-us-text">
                                        Count memories, no miles-truly unlimited Kms.                        
                                     </div>
                                  </div>
                               </div>
                              
                              <div class="item items1 col-md-4 mb-3">
                                  <div class="why-us-row">
                                    <div class="why-us-image">
                                        <img src="<?= base_url(); ?>assets/img/why/cashback.png" alt="" class="img-fluid">
                                    </div>
                                    <div class="why-us-text">
                                        Refund within 24 hours.                        
                                     </div>
                                  </div>
                               </div>

                           </div>

                         </div>
                         <div class="why-us-scroll carousel-item">

                           <div class="row">
                              
                              <div class="item items1 col-md-4 mb-3">
                                  <div class="why-us-row">
                                    <div class="why-us-image">
                                        <img src="<?= base_url(); ?>assets/img/why/customer-support.png" alt="" class="img-fluid">
                                    </div>
                                    <div class="why-us-text">
                                        24 X 7 customer support.                       
                                     </div>
                                  </div>
                               </div>
                              
                              <div class="item items1 col-md-4 mb-3">
                                  <div class="why-us-row">
                                    <div class="why-us-image">
                                        <img src="<?= base_url(); ?>assets/img/why/calendar.png" alt="" class="img-fluid">
                                    </div>
                                    <div class="why-us-text">
                                        Paperless booking process                      
                                     </div>
                                  </div>
                               </div>
                              
                              <div class="item items1 col-md-4 mb-3">
                                  <div class="why-us-row">
                                    <div class="why-us-image">
                                        <img src="<?= base_url(); ?>assets/img/why/car-wash.png" alt="" class="img-fluid">
                                    </div>
                                    <div class="why-us-text">
                                        Clean & sanitized cars.                      
                                    </div>
                                  </div>
                               </div>

                           </div>
                            
                        </div>
                       </div>
                     </div>
                   
                     <button class="carousel-control-prev" type="button" data-bs-target="#whyhappyeasy" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                     </button>
                     
                     <button class="carousel-control-next" type="button" data-bs-target="#whyhappyeasy" data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                     </button>
                  
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
-->

<section class="why-happy-easy-rides custom-padding-1" >
   
   <div class="container">
      <div class="row">
         <div class="col-xl-12">
            
            <div class="custom-heading-1">
               <h4>Why Happyeasy Rides</h4>
            </div>
            
            <div class="row">
               <div class="col-lg-12">
                  <div id="whyhappyeasy" class="carousel slide" data-bs-ride="carousel">
                    
                     <div class="carousel-inner active">
                       <div class="mobile_slides">
                         <div class="why-us-scroll carousel-item active">
                              <div class="item items1 col-md-4 mb-3">
                                  <div class="why-us-image-d">
                                        <img src="<?= base_url(); ?>/assets/img/why-ride-banner-1.png" alt="happyeasyrides" class="img-fluid">
                                  </div>
                               </div>
                         </div>
                         <div class="why-us-scroll carousel-item">
                              <div class="item items1 col-md-4 mb-3">
                                  <div class="why-us-image-d">
                                        <img src="<?= base_url(); ?>/assets/img/why-ride-banner-2.png" alt="happyeasyrides" class="img-fluid">
                                  </div>
                               </div>
                              </div>
                         <div class="why-us-scroll carousel-item">
                              <div class="item items1 col-md-4 mb-3">
                                  <div class="why-us-image-d">
                                        <img src="<?= base_url(); ?>/assets/img/why-ride-banner-3.png" alt="happyeasyrides" class="img-fluid">
                                  </div>
                               </div>
                        </div>
                         <div class="why-us-scroll carousel-item">
                             <div class="item items1 col-md-4 mb-3">
                                  <div class="why-us-image-d">
                                        <img src="<?= base_url(); ?>/assets/img/why-ride-banner-4.png" alt="happyeasyrides" class="img-fluid">
                                  </div>
                               </div>
                         </div>
                         <div class="why-us-scroll carousel-item">
                             <div class="item items1 col-md-4 mb-3">
                                  <div class="why-us-image-d">
                                        <img src="<?= base_url(); ?>/assets/img/why-ride-banner-5.png" alt="happyeasyrides" class="img-fluid">
                                  </div>
                               </div>
                         </div>
                       </div>
                       <div class="desktop_slides">   
                                        
                         <div class="why-us-scroll carousel-item active">
                  
                           <div class="row">
                              
                              <div class="item items1 col-md-4 mb-3">
                                  <div class="why-us-image-d">
                                        <img src="<?= base_url(); ?>/assets/img/why-ride-banner-1.png" alt="happyeasyrides" class="img-fluid">
                                  </div>
                               </div>
                              
                              <div class="item items1 col-md-4 mb-3">
                                  <div class="why-us-image-d">
                                        <img src="<?= base_url(); ?>/assets/img/why-ride-banner-2.png" alt="happyeasyrides" class="img-fluid">
                                  </div>
                               </div>
                              
                              <div class="item items1 col-md-4 mb-3">
                                  <div class="why-us-image-d">
                                        <img src="<?= base_url(); ?>/assets/img/why-ride-banner-3.png" alt="happyeasyrides" class="img-fluid">
                                  </div>
                               </div>

                           </div>

                         </div>
                         <div class="why-us-scroll carousel-item">

                           <div class="row">
                              
                              <div class="item items1 col-md-4 mb-3">
                                  <div class="why-us-image-d">
                                        <img src="<?= base_url(); ?>/assets/img/why-ride-banner-4.png" alt="happyeasyrides" class="img-fluid">
                                  </div>
                               </div>
                              
                              <div class="item items1 col-md-4 mb-3">
                                  <div class="why-us-image-d">
                                        <img src="<?= base_url(); ?>/assets/img/why-ride-banner-5.png" alt="happyeasyrides" class="img-fluid">
                                  </div>
                               </div>
                              
                              <div class="item items1 col-md-4 mb-3">
                                  <div class="why-us-image-d">
                                        <img src="<?= base_url(); ?>/assets/img/why-ride-banner-1.png" alt="happyeasyrides" class="img-fluid">
                                  </div>
                               </div>

                           </div>
                            
                        </div>
                       </div>
                     </div>
                   
                     <button class="carousel-control-prev" type="button" data-bs-target="#whyhappyeasy" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                     </button>
                     
                     <button class="carousel-control-next" type="button" data-bs-target="#whyhappyeasy" data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                     </button>
                  
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<section class="why-happy-easy-rides custom-padding-1 offer-section-1" >
   
   <div class="container">
      <div class="row">
         <div class="col-xl-12">
            
            <div class="custom-heading-1">
               <h4>Offers</h4>
            </div>
            
            <div class="row">
               <div class="col-lg-12">
                  <div id="offershappyeasy" class="carousel slide" data-bs-ride="carousel">
                    
                     <div class="carousel-inner active">
                       <div class="mobile_slides">
                        
                           <?php $a = 1;
               $images = $this->db->get_where('coupon', ['secret'=>0])->result();
               
               foreach($images as $i){
                   
                   
                   $image_path = base_url($i->image);
                   
                   
                           ?>
               <div class="why-us-scroll carousel-item <?= $a==1?"active":""; ?>">
            <div data-bs-toggle="modal" data-bs-target="#exampleModal<?= $a; ?>"  class="item items1 col-xl-5 col-md-6 <?php //(fmod($a, 2) != 0) ? 'offset-1':''; ?>  d-flex align-items-stretch mt-4">
               <img src="<?= $image_path; ?>" alt="happyeasyrides" class="img-fluid" >
            </div> 
                           </div>
                           
           <!-- Modal -->
<div class="modal fade" id="exampleModal<?= $a; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">
            Flat <?= $i->percent ?>% Off <br/>
            <font size="2">Use code <?= $i->name ?> and get flat <?= $i->percent ?>% off</font>
        </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
         
         <div class="form-group input-group">
             <input type="text" readonly id="coupon<?= $a; ?>" class="form-control" value="<?= $i->name ?>"/>
             <div class="input-append">
                 <button type="button" row="<?= $a; ?>" class="copy btn btn-success" style="border-radius: 0px !important; height: 40px !important">Copy</button>
             </div>
         </div>
         
         <br/>
         <h5>Terms and Conditions</h5> 
         <?= $i->terms; ?> 
         
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>
                           
            <?php $a++; }  ?>
                        
                       </div>
                       <div class="desktop_slides">   
                                        
                         <div class="why-us-scroll carousel-item active">
                  
                           <div class="row">
                              
                              <?php $a = 1;
               $images = $this->db->get_where('coupon', ['secret'=>0])->result();
               
               foreach($images as $i){ 
                              
                               ?>
               
            <div data-bs-toggle="modal" data-bs-target="#exampleModal<?= $a; ?>" class="item items1 col-md-4 <?php //(fmod($a, 2) != 0) ? 'offset-1':''; ?>  d-flex align-items-stretch">
               <img alt="happyeasyrides" src="<?= base_url().$i->image; ?>" class="img-fluid" >
            </div>
            
<!-- Modal -->
<div class="modal fade" id="exampleModal<?= $a; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">
            Flat <?= $i->percent ?>% Off <br/>
            <font size="2">Use code <?= $i->name ?> and get flat <?= $i->percent ?>% off</font>
        </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
         
         <div class="form-group input-group">
             <input type="text" readonly id="coupon<?= $a; ?>" class="form-control" value="<?= $i->name ?>"/>
             <div class="input-append">
                 <button type="button" row="<?= $a; ?>" data-bs-dismiss="modal" class="copy btn btn-success" style="border-radius: 0px !important; height: 40px !important">Copy</button>
             </div>
         </div>
         
         <br/>
         <h5>Terms and Conditions</h5> 
         <?= $i->terms; ?> 
         
      </div>
    </div>
  </div>
</div>
            
            
            <?php $a++; }  ?>
                              
                              
                           </div>

                         </div>
                         
                       </div>
                     </div>
                   
                     <button class="carousel-control-prev" type="button" data-bs-target="#offershappyeasy" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                     </button>
                     
                     <button class="carousel-control-next" type="button" data-bs-target="#offershappyeasy" data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                     </button>
                  
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>






<main id="main">
  
  <!--
   <section id="services" class="services section-bg">
      <div class="">
         <div class="row">
            <?php $a = 1;
               $images = $this->db->get('results')->result();
               
               foreach($images as $i){ ?>
            <div class="col-xl-5 col-md-6 <?= (fmod($a, 2) != 0) ? 'offset-1':''; ?>  d-flex align-items-stretch mt-4">
               <img src="<?= base_url().$i->images; ?>" class="img-fluid" >
            </div>
            <?php $a++; }  ?>
         </div>
      </div>
   </section>
  -->

   

   <section class="section-bg-1">
    <?php
                                $this->db->order_by("id", "desc");
                                $this->db->limit(1);
                                $testimonial_bg = $this->db->get("testimonial_bg")->row()->images;
                            ?>
     <style>
        
        #carouselExampleControlsreview{
            width: 100%;
            height: 100%;
            position: relative;
            z-index: 5;
            padding: 90px 0; 
            background:linear-gradient(rgba(0 0 0 / 70%),rgba(0 0 0 / 70%)), url(<?= base_url($testimonial_bg); ?>); 
            background-repeat: no-repeat; 
            background-position: center; 
            background-size: cover; 
            -webkit-filter: grayscale(100%); 
            filter: grayscale(100%);
        }
        
        #carouselExampleControlsreview .carousel-inner{
            -webkit-filter: none !important;
             filter: none !important;
        }
       </style>
      <div class="container-fluid" id="review">
         <div class="row">
            <div class="col-lg-12">
               <div id="carouselExampleControlsreview" class="carousel slide" data-bs-ride="carousel">
                 
                  <div class="carousel-inner text-center">

                        <label><i class='bx bxs-quote-left' style="color: #00E66D !important; font-size: 4em;"></i></label>
                     <?php $a = 1; $comments = $this->db->order_by('id','desc')->get('testimonial')->result();
                        
                        foreach($comments as $c){  $b = 1; ?>
                        


                        <div class="carousel-item text-center <?php if($a == $b) echo 'active'; ?>">
                           <p class="text-center">
                              <?= $c->review; ?>
                           </p>
                           <h3 class="text-center text" style="color: #00E66D;"><?= $c->name; ?></h3>
                        </div>
                     <?php $b++; $a++; } ?>
                  </div>
                
                  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControlsreview" data-bs-slide="prev">
                     <span class="carousel-control-prev-icon mt-5" aria-hidden="true"></span>
                     <span class="visually-hidden">Previous</span>
                  </button>
                  
                  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControlsreview" data-bs-slide="next">
                     <span class="carousel-control-next-icon mt-5" aria-hidden="true"></span>
                     <span class="visually-hidden">Next</span>
                  </button>
               
               </div>
            </div>
         </div>
      </div>
   </section>


   <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/css/slider.css">

   <style type="text/css">
      .leftLst, .rightLst{
         background: radial-gradient(rgba(19,195,149,0.8),rgba(19,195,149,0.8)) !important;
      }
   </style>

  <!--
   <section class="section-bg">
      <div class="container-fluid" id="cars">
         <div class="row">
            <div class="col-md-12 text-center">
               <h4 class="heading01">POPULAR SELF DRIVEN CARS</h4>
            </div>
            <div class="col-lg-12">
               <div class="row">
                  <div class="MultiCarousel" data-items="1,2,3,4" data-slide="1" id="MultiCarousel"  data-interval="100">
                        <div class="MultiCarousel-inner">
                           <?php $cars = $this->db->get_where('car', array('status'=>1))->result();
                              foreach($cars as $c){ ?>
                               <div class="item">
                                   <div class="pad15">
                                      <img src="<?= base_url().$c->image; ?>" class="img-fluid" style="width: auto; height: 200px;">
                                   </div>
                               </div>
                            <?php } ?>
                        </div>
                        <button class="btn btn-info leftLst"><</button>
                        <button class="btn btn-info rightLst">></button>
                    </div>
               </div>
            </div>
         </div>
      </div>
   </section>
-->

<script type="text/javascript" src="<?= base_url(); ?>assets/js/slider.js"></script>
<!--
   <section id="team" class="team" style="background: lightgrey;">
      <div class="container">
         <div class="row">
            <div class="col-lg-6 mt-4">
               <div class="member d-flex align-items-start" data-aos="zoom-in" data-aos-delay="300">
                  <div class="pic"><img src="<?= base_url(); ?>assets/img/icons/r1.png" class="img-fluid" alt="" ></div>
                  <div class="member-info  pt-5">
                     <h4>Refern & Earn</h4>
                     <p>Quisquam facilis cum velit laborum corrupti fuga rerum quia</p>
                  </div>
               </div>
            </div>
            <div class="col-lg-6 mt-4">
               <div class="member d-flex align-items-start" data-aos="zoom-in" data-aos-delay="400">
                  <div class="pic"><img src="<?= base_url(); ?>assets/img/icons/r2.png" class="img-fluid" alt=""></div>
                  <div class="member-info pt-5">
                     <h4>Login</h4>
                     <p>Dolorum tempora officiis odit laborum officiis et et accusamus</p>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
   -->
   
   <!-- End Team Section -->
   
   <!--
   <section id="offer">
      <div class="container-fluid">
         <p class="text-center" style="font-weight: bold;">OFFERS</p>
         <div class="row mt-3">
            <div class="col-md-4 row">
               <div class="col-md-5">
                  <img src="<?= base_url(); ?>assets/img/icons/o1.png" class="img-fluid" />
               </div>
               <div class="col-md-7">
                  <h5 class="mt-3">Get 10% off</h5>
                  <small>On your first Singup & Booking</small>
                  <button type="button" class="btn btn-outline-primary btn-rounded mt-4">Get Offer</button>
               </div>
            </div>
            <div class="col-md-4 row">
               <div class="col-md-5">
                  <img src="<?= base_url(); ?>assets/img/icons/o2.png" class="img-fluid" />
               </div>
               <div class="col-md-7">
                  <h5 class="mt-3">Free Home Delivery</h5>
                  <small>For booking Over 72 hours</small>
                  <button type="button" class="btn btn-outline-primary btn-rounded mt-4">Get Offer</button>
               </div>
            </div>
            <div class="col-md-4 row">
               <div class="col-md-5">
                  <img src="<?= base_url(); ?>assets/img/icons/o4.png" class="img-fluid" />
               </div>
               <div class="col-md-7">
                  <h5 class="mt-3">Book a SUV</h5>
                  <small>For 7 days and get 1 day fress</small>
                  <button type="button" class="btn btn-outline-primary btn-rounded mt-4">Get Offer</button>
               </div>
            </div>
         </div>
      </div>
   </section>
  -->
  
    <style>
        #slide .card{
              box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;
        }
    </style>

   <section class="servicable-cities">
       <div class="container">
      <div class="row">
         <div class="col-md-12">
            <div class="custom-heading-1" >
               <h4 class="">SERVICEABLE CITIES</h4>
            </div>
         </div>
      </div>
      <div class="slider" id="slider">
         <div class="slide" id="slide">
             <div class="card" style="width: 22rem;">
               <img alt="happyeasyrides" class="item" src="<?= base_url(); ?>assets/img/amritsar.jpg">
               <div class="card-body">
                  <h5 class="card-title text-center">Car Rental In Amritsar</h5>
                  <p class="card-text text-center">S404 Basant Avenue, Near Rajender Public School Amritsar 143001</p>
               </div>
            </div>
            <div class="card" style="width: 22rem;">
               <img alt="happyeasyrides" class="item" src="<?= base_url(); ?>assets/img/bangluru.jpg">
               <div class="card-body">
                  <h5 class="card-title text-center">Car Rental In Bengaluru</h5>
                  <p class="card-text text-center">CV Raman Circle, Amruthahalli Main Rd, Bengaluru, Karnataka 560092</p>
               </div>
            </div>
            <div class="card" style="width: 22rem;">
               <img alt="happyeasyrides" class="item" src="<?= base_url(); ?>assets/img/chandigarah.jpg">
               <div class="card-body text-center">
                  <h5 class="card-title text-center">Car Rental In Chandigarh</h5>
                  <p class="card-text text-center">SCO 34A Parking, Near DHL office, Chandigarh 160022</p>
                  <!-- <a href="#" class="btn btn-primary">Go somewhere</a>-->
               </div>
            </div>
            <div class="card" style="width: 22rem;">
               <img alt="happyeasyrides" class="item" src="<?= base_url(); ?>assets/img/dehradun.jpg">
               <div class="card-body">
                  <h5 class="card-title text-center">Car Rental In Dehradun</h5>
                  <p class="card-text text-center">MDDA Complax Parking, Clock Tower, Dehradun 248001</p>
               </div>
            </div>
            <div class="card" style="width: 22rem;">
               <img alt="happyeasyrides" class="item" src="<?= base_url(); ?>assets/img/delhi.jpg">
               <div class="card-body">
                  <h5 class="card-title text-center">Car Rental In Delhi NCR</h5>
                  <p class="card-text text-center">SF 32, 14th Avenue High Street, Commercial Market, Gaur City 2, Greater Noida West 201009</p>
               </div>
            </div>
         </div>
         <!-- <button class="ctrl-btn pro-prev">Prev</button>
            <button class="ctrl-btn pro-next">Next</button>-->
      </div>
      </div>
   </section>
   <!--coming soon banner-->
   
   <img alt="happyeasyrides" src="<?= base_url(); ?>assets/img/coming-soon-banner-2.png" class="img-fluid" >
   
   <!-- ======= Frequently Asked Questions Section ======= -->
   <!--<section id="faq" class="faq">
      <div class="container-fluid" data-aos="fade-up">
      <div class="row">
         <div class="col-md-12">
            <div class="section-title" style="background: lightgray;">
               <h5 class="text-dark" data-bs-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">About Us <i class='bx bxs-chevron-down'></i></h5>
            </div>
         </div>
         <div class="col-md-12 collapse" id="collapseExample">
            <div class="container faq-list">
               <div class="col-md-12 mb-5">
                  <h5 class="text-uppercase text-center mx-3" data-bs-toggle="collapse" href="#self_drive" role="button" aria-expanded="false" aria-controls="self_drive">Self drive cars in mumbai</h5>
                  <div class="col-md-12  collapse" id="self_drive">
                     <p class="text-justify mx-3">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                     <br/>
                  </div>
               </div>
               <div class="col-md-12 mb-5">
                  <h5 class="text-uppercase text-center mx-3" data-bs-toggle="collapse" href="#car_rental" role="button" aria-expanded="false" aria-controls="car_rental">Car Rental in mumbai</h5>
                  <div class="col-md-12  collapse" id="car_rental">
                     <p class="text-justify mx-3">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                     <br/>
                  </div>
               </div>
               <div class="col-md-12 mb-5">
                  <h5 class="text-uppercase text-center mx-3" data-bs-toggle="collapse" href="#rent_car" role="button" aria-expanded="false" aria-controls="rent_car">Rent a Car in mumbai</h5>
                  <div class="col-md-12  collapse" id="rent_car">
                     <p class="text-justify mx-3">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                     <br/>
                  </div>
               </div>
               <div class="col-md-12 mb-5">
                  <h5 class="text-uppercase text-center mx-3" data-bs-toggle="collapse" href="#about" role="button" aria-expanded="false" aria-controls="about">About Happyeasy Drives</h5>
                  <div class="col-md-12  collapse" id="about">
                     <p class="text-justify mx-3">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
                     <br/>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>-->
   <!-- End Frequently Asked Questions Section -->
</main>
<script>
   "use strict";
   
   productScroll();
   
   function productScroll() {
      let slider = document.getElementById("slider");
      let next = document.getElementsByClassName("pro-next");
      let prev = document.getElementsByClassName("pro-prev");
      let slide = document.getElementById("slide");
      let item = document.getElementById("slide");
      
      for (let i = 0; i < next.length; i++) {
      
      let position = 0;
      
      prev[i].addEventListener("click", function() {
        if (position > 0) {
          position -= 1;
          translateX(position);
        }
      });
      
      next[i].addEventListener("click", function() {
        if (position >= 0 && position < hiddenItems()) {
          position += 1;
          translateX(position);
        }
      });
      }
      
      function hiddenItems() {
         let items = getCount(item, false);
         let visibleItems = slider.offsetWidth / 210;
         return items - Math.ceil(visibleItems);
      }
   }
   
   function translateX(position) {
      slide.style.left = position * -210 + "px";
   }
   
   function getCount(parent, getChildrensChildren) {
         let relevantChildren = 0;
         let children = parent.childNodes.length;
         for (let i = 0; i < children; i++) {
         if (parent.childNodes[i].nodeType != 3) {
           if (getChildrensChildren)
             relevantChildren += getCount(parent.childNodes[i], true);
           relevantChildren++;
         }
      }
      return relevantChildren;
   }
   
    if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
        $("form").removeClass("form");
        $("form").addClass("mt-3");
        $("div").removeClass("form");
        
        $(".desktop_slides").remove();
    }else{
        $(".mobile_slides").remove();
    }
</script>

<script>
   $(document).ready(function() {
    $('#autoWidth').lightSlider-product({
        autoWidth:true,
        loop:true,
        onSliderLoad: function() {
            $('#autoWidth').removeClass('cS-hidden');
        } 
    });  
   });
</script>
<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/style1.css" />
<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/lightslider.css" />
<script src="<?= base_url(); ?>assets/lightslider.js" ></script>