<section></section>
<style>
    .section-title h2::after{
        display: none !important;
    }
    .section-title h2{
        position: inherit;
    }
    table{
        width: 100% !important;
    }
</style>
<main id="contact" class="py-5 cancellation-policy">
	
	<section id="contact" class="contact" style="background: #fff;">
      <div class="container">
        <nav aria-label="breadcrumb" class="">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">About Us</li>
          </ol>
        </nav>
        
        <div class="section-title">
          <h2>About Us</h2>
        </div>

        <div class="row">
            <div class="tnc-text-continaer">
                <?= $this->db->get_where("about_us", ["aid"=>1])->row()->about_us; ?>
            </div>

       </div>
      </div>
    </section>

</main>