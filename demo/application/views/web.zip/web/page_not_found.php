<section></section>
<style>
    .section-title h2::after{
        display: none !important;
    }
    .section-title h2{
        position: inherit;
    }
</style>
<main id="contact" class="py-5 pagenotfound">
	
	<section id="contact" class="contact" style="background: #fff;">
      <div class="container">

        <div class="row">
                <div class="col-md-12 text-center">
                 <img src="<?= base_url(); ?>assets/img/image-404.jpg">
            </div>
        </div>

      </div>
    </section>

</main>