<style>
     .upload_doc{
        background: linear-gradient(145deg, rgba(20,201,148,0.8),rgb(6,135,167)) !important;
        color: white !important;
        border: none !important;
        border-radius: 20px !important;
    }
</style>

<style>
    .section-title h2::after{
        display: none !important;
    }
    .section-title h2{
        position: inherit;
    }
</style>


<?php $user = $this->db->get_where('user', array('user_id'=>$this->session->userdata('user_id')))->result();

  foreach($user as $u){ ?>

<section></section>
<main id="contact" class="py-5 my-account-page">
	
	<section id="contact" class="contact">
      <div class="container">

<nav aria-label="breadcrumb" class="">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
    <li class="breadcrumb-item active" aria-current="page">My Account</li>
  </ol>
</nav>
       
        <div class="section-title">
          <h2 class="text-white">My Account</h2>
        </div>

        <div class="row my-acount-inner">
          
          <div class="col-md-3">
            
            <div class="card sidebar">
              
              <div class="card-body text-center btn_profile_edit">
                
               <div class="row profile_view">
                 
                 <div class="col-sm-12 hlaf_view1">
                    <?php if($u->image == null){ ?>
                    <img alt="happyeasyrides" src="<?= base_url(); ?>uploads/user/default.png" class="img img-thumbnail" width="100" />
                  <?php } else { ?>
                    <img alt="happyeasyrides" src="<?= base_url().$u->image; ?>" class="img img-thumbnail" alt="" width="100"  />
                  <?php } ?>
                 </div>

                 <div class="col-sm-12 hlaf_view2">
                  <p><?= $u->name; ?></p>
                  <p><?= $u->contact; ?></p>
                  <p><?= $u->email; ?></p>
                 </div>

               </div>

                <hr/>

                <a href="<?= base_url(); ?>Account" class="btn btn-block btn-outline-dark py-2 mb-3">Edit Profile</a>

                <a href="<?= base_url(); ?>Account/history" class="btn btn-block btn-outline-dark py-2 mb-3">Booking History</a>

                <a href="<?= base_url(); ?>Account/documents" class="btn btn-block btn-outline-dark py-2 mb-3">Manage Documents</a>

                <a href="<?= base_url(); ?>Account/verification" class="btn btn-block btn-outline-dark py-2 mb-3">Profile Verification</a>

              </div>

            </div>

          </div>
          
          <div class="col-md-9">
            
            <div class="card right-content" >
              
              <div class="card-header">
                
                <h3 class="text-center">My Account</h3>

              </div>

              <form action="<?= base_url(); ?>Account/update_profile" method="post" enctype="multipart/form-data" >
                
                <div class="card-body">

                  <div class="row">
                    
                    <div class="col-md-6">
                      <div class="form-group">
                        <label>Name</label>
                        <input type="text" class="form-control" name="name" value="<?= $u->name; ?>" autocomplete="off">
                      </div>
                    </div>
                    
                    <div class="col-md-6">
                      <label>User Image</label>
                      <div class="form-group row">
                        <div class="col-md-6">
                          <input type="file" name="image" class="form-control" onchange="readURL(this);" />
                        </div>
                        <div class="col-md-6">
                          <?php if($u->image == null){ ?>
                            <img src="<?= base_url(); ?>uploads/user/default.png" id="blah" alt="happyeasyrides" width="auto" height="100px" />
                          <?php } else { ?>
                            <img src="<?= base_url().$u->image; ?>" id="blah" alt="happyeasyrides" width="auto" height="100px" />
                          <?php } ?>
                        </div>
                      </div>
                    </div>
                    
                    <div class="col-md-6 mt-3">
                      <div class="form-group">
                        <label>Email Address</label>
                        <input type="text" class="form-control" name="email" value="<?= $u->email; ?>" autocomplete="off" />
                      </div>
                    </div>
                    
                    <div class="col-md-6 mt-3">
                      <div class="form-group">
                        <label>Contact Number</label>
                        <input type="number" class="form-control" name="contact" readonly value="<?= $u->contact; ?>" autocomplete="off" />
                      </div>
                    </div>
                    
                    <div class="col-md-6 mt-3">
                      <div class="form-group">
                        <label>Password <small>(If you Need to Change Password)</small></label>
                        <input type="password" class="form-control" name="password" autocomplete="off" />
                      </div>
                    </div>
                    
                    <div class="col-md-6 mt-3">
                      <div class="form-group">
                        <label>Confirm Password <small>(If you Need to Change Password)</small></label>
                        <input type="password" class="form-control" name="cpassword"  autocomplete="off" />
                      </div>
                    </div>

                    <input type="hidden" class="form-control" name="user_id" value="<?= base64_encode($u->user_id); ?>" />

                  </div>
                  
                </div>

                <div class="card-footer text-center">
                  
                  <button type="submit" class="btn btn btn-lg upload_doc my-3">Update Profile</button>

                </div>

              </form>

            </div>

          </div>

        </div>


      </div>
    </section>

</main>

<?php } ?>