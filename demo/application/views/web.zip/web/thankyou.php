<section></section>

<main id="email" class="py-5">
   <div class="container">
      <div class="row">
         <div class="col-md-12 mb-3">
           
           <div class="text-center">

               <img alt="happyeasyrides" src="<?= base_url(); ?>assets/img/check.gif" width="200px" />

               <h1 class="mt-5">Your Booking is confirmed !! </h1>

               <a href="<?= base_url(); ?>Account" class="btn btn-primary p-3 mt-5" >Go Back My Account</a>
            
            </div>

         </div>
      </div>
   </div>
</main> 
