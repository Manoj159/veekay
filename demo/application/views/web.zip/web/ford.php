<?php  $pick_data = $this->db->get_where('settings', "settings_id=12 OR settings_id=13 OR settings_id=14")->result();
         
      $pick_start_time = $pick_end_time = $price_increase_percentage = "";
      foreach($pick_data as $p){ 
         if($p->settings_id == 12){
            $pick_start_time = $p->description;
         }
         elseif($p->settings_id == 13){
            $pick_end_time = $p->description;
         }
         elseif($p->settings_id == 14){
            $price_increase_percentage = $p->description;
         }

      }  ?>

<style>
    .date{
       font-size: 14px;
       line-height: 20px;
       font-weight: 400;
       letter-spacing: 0.24px;
       color: #1f1f1f;
    }
    .ppart{
        background-color: #f0f4ff;
       padding: 12px 40px 12px 16px;
       margin-top: 16px;
      border-radius: 4px;
    }
    .car_name{
       font-size: 18px;
       font-weight: 600;
       line-height: 24px;
       letter-spacing: 0.16px;
       color: #1f1f1f;
    }
    .car_info{
        display: block;
       font-size: 12px;
       line-height: 16px;
       font-weight: 400;
       letter-spacing: 0.4px;
       color: #666;
    }
    @media(max-width: 500px){
        #fares p {
            font-size: 13px;
        }
        .prices{
            box-shadow: none !important;
            border:  none !important;
            background: #e9ecef !important;
        }
        
        .card-body{
            padding: 0 !important;
        }
        .row{
            --bs-gutter-x: .5rem !important;
        }
        
        .small_hai{
            font-size: 12px !important;
        }
        
        .ppart p{
            font-size: 12px !important;
        }
        
        #home_del .date{
            padding-left: 15px;
        }
        
        #home_del_hai label, #home_del_hai span{
           margin-top: -20px !important;
            font-size: 12px !important;
        }
        
        #address, #final_things{
             padding: 0 15px;
        }
        
        #address span{
            font-size: 13px !important;
        }
    }
    
    .card-body #bdate{
        padding: 0px !important;
    }
    #home_del .date{
        margin-left: 7px;
    }

    #home_del_hai label, #home_del_hai span{
       margin-top: -20px !important;
    }
     .btn{
        background: linear-gradient(25deg, rgba(20,201,148,0.8),rgb(6,135,167)) !important;
        color: white !important;
        border: none !important;
    }
</style>

<main id="main_search" class="mt-2">


   <div class="container pt-4">
     
   
     
      <div class="row mt-5 pb-5">
      
<nav aria-label="breadcrumb" class="mt-1">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Home</a></li>
    <li class="breadcrumb-item"><a href="<?= $_SERVER["HTTP_REFERER"]; ?>">Book Cars</a></li>
    <li class="breadcrumb-item active" aria-current="page">Booking Summary</li>
  </ol>
</nav>
         <div class="col-lg-8 offset-2 car-booking-before-detail-outer">

            <?php foreach($car as $c){ ?>
            
            <div class="card car-booking-before-detail">
               
               <div class="card-body">

                  <div class="col-md-12 car_info">
                      <div class="row">
                          <div class="col-md-6">
                              <h5 class="px-2 car_name"><?= $c->name; ?></h5>
                               
                                 <i class="fa fa-flag px-2" aria-hidden="true"></i><?= $c->transmission; ?> &nbsp;&nbsp;
                               
                                 <i class="fas fa-gas-pump px-2 mt-2"></i> <?= $c->fuel; ?> 

                          </div>
                          <div class="col-md-6 text-center">
                                 <img alt="happyeasyrides" src="<?= base_url().$c->image; ?>" class="img-fluid" width="auto" style="max-height: 100px;">
                          </div>
                      </div>
                      
                  </div>

               <div class="row mx-2">
                  <div class="col-md-12" id="bdate" style="border: 1px solid #e3e3e3; padding: 14px!important; border-radius: 5px;margin-bottom: 8px;">
                     <h4 class="start-date"><i class='bx bxs-circle text-success'></i>
                         <b>From </b> &nbsp;<?= @date('d M, Y H:i', strtotime($_GET['start'])); ?></h4>
                    
                     <h4 class="end-date mt-2"><i class='bx bxs-circle text-danger'></i><b>To</b> &nbsp;<?= @date('d M, Y H:i', strtotime($_GET['end'])); ?></h4>
                    <small class='small_hai'><?= $c->place ?> <?= $this->db->get_where('city', array('city_id'=>$c->city))->row()->name; ?></small>
                  </div>

                  <div class="col-md-12 duration" id="bdate">
                     
                     <?php $start = new DateTime($this->session->userdata('start'));
                             $end = new DateTime($this->session->userdata('end'));

                             $main = $start->diff($end); 
                                      
                             $total_days = 0;
                                      
                             // if booking is less than 24 Hrs.
                             $isLessThan_24Hrs = 0;
                             if($main->d == 0 && $main->h < 24){
                                $isLessThan_24Hrs = 1;    
                             }
                             // end..
                                      
                             if($main->h > 0){
                               $total_days = $main->d;
                               $main_date = $main->d. " Days & ".$main->h." Hours";
                             }else{
                               $total_days = $main->d;
                               $main_date = $main->d. " Days";
                             } 
                            
                            
                             if($this->session->userdata("coupon_total_days")){
                                 $coupon_total_days = $this->session->userdata("coupon_total_days");
                                 if($total_days < $coupon_total_days){
                                    $this->session->unset_userdata("coupon_discount");
                                    $this->session->unset_userdata("coupon_name");   
                                 }
                             }
                            
                             $mdate = $main->d*24 +$main->h;
                           
                             /* $period = new DatePeriod($start, new DateInterval('P1D'),$end);

                             $date_range = array();

                             foreach ($period as $key => $value) {
                                  $range = $value->format('Y-m-d');  
                                 
                                 array_push($date_range, $range);
                              } */
                                      
                           // sanjay added 31-03-2022
                              $interval = DateInterval::createFromDateString('1 hour');
                              $period = new DatePeriod($start, $interval, $end);
                              $overall_fare = 0;
                                
                              $reg_hrs = 0;
                              $week_hrs = 0;
                                      
                              foreach ($period as $dt) {
                                  //note:- looping through every one hour from start to end datetime
                                  //echo $dt->format("l Y-m-d H:i:s\n")."<br/>";
                                  $date_day = $dt->format("l"); //checking for the weekend day in current loop hour.
                                  if($date_day=="Saturday" || $date_day=="Sunday"){
                                      $overall_fare = $overall_fare+$c->weekend_price;
                                      $week_hrs++;
                                  }else{
                                      $overall_fare = $overall_fare+$c->price;
                                      $reg_hrs++;
                                  }

                                  // sanjay
                                  $dateDiff2 = $dt->format("Y-m-d H:i:s"); // 13,14,15,16

                                  $percentToApply = $percentAddon = 0;
                                  
                                  if($dateDiff2 >= $pick_start_time && $dateDiff2 <= $pick_end_time){ // 15,16
                                      $percentToApply = $price_increase_percentage;
                                  }
                                  
                                  if($percentToApply > 0){
                                   $percentAddon = (($overall_fare*$percentToApply)/100);
                                  }
                              }
                                      //echo $week_hrs." ".$reg_hrs;
                           // end.. sanjay added 31-03-2022
                         ?>

                        <h6 class="mt-2"><span class="">Booking Duration:</span> &nbsp;&nbsp;<span><?= $main_date; ?></span></h6>
                        
                        <?php
                                      if($isLessThan_24Hrs > 0){
                                      ?>
                        <span class="">Minimum booking duration is 24 hours</span>
                        <?php
                                      }
                                          ?>
                  </div>

               </div>
            
               <div class="row mx-2">
                  
                  <div class="col-md-12 py-2 ppart" style="background: rgb(221 249 240); border: 1px solid #a8e1ce;">
                     <p style="color: #252525!important; margin: 0px; padding: 5px 0;">Fuel Not Included</p>
                  </div>
                  <div class="home-delivery-confirmation">
                  <div class="" id="home_del">
                     <h3 class="date">Home Delivery</h3>
                  </div>
                  
                     <?php 
                          $home_delivery = $c->home_delivery_charge;
                          if($home_delivery == 0){          
                            $home_delivery = $this->db->get_where('settings', array('type'=>'home_delivery'))->row()->description; 
                          }
                      ?>

                  <div class=""  id="home_del_hai">
                    
                    <!-- <h4 class="date"><i class="fas fa-car px-2" aria-hidden="true"></i>Home pickup & drop at <i class='bx bx-rupee'></i><?= $home_delivery; ?></h4> -->
                     
                     <?php 
                         $time_now = date("H:i", strtotime($this->session->userdata('start')));
                         $delivery_close_from = date("H:i", strtotime("11:00 PM"));
                         $delivery_close_to = date("H:i", strtotime("07:00 AM"));
                             
                         $showAddressBox = 1;          
                         if($time_now>$delivery_close_from || $time_now<$delivery_close_to){
                             $this->session->unset_userdata('check');
                             $showAddressBox = 0;
                     ?>
                     <span class="text-danger">
                         Home delivery is not available from <?= date("h:i A", strtotime($delivery_close_from)); ?> to <?= date("h:i A", strtotime($delivery_close_to)); ?> 
                     </span>
                     <?php         
                         }else{
                     ?>
                    <label style="background: none; font-size: 14px">
                        <input class="form-check-input" type="checkbox" id="check1" name="option1" value="1" <?php if($this->session->userdata('check')!= ''){ echo 'checked';} ?> >&nbsp;Get the car deliverd and picked up from your doorstep at just  <i class='bx bx-rupee'></i><?= $home_delivery; ?>
                    </label>
                    <?php
                         }
                    ?>
                  </div>
                    </div>

                  <div class="col-md-12 <?= ($showAddressBox==0)?"d-none":""; ?>" id="address" <?php if($this->session->userdata('check') == ''){ echo 'style="display: none;"'; } ?> >
                     
                     <form id="add_address" method="post">

                        <input type="hidden" name="user_id" id="user_id" value="<?= $this->session->userdata('user_id'); ?>">
                           
                        <span>Enter Full Address</span>
                        <textarea class="form-control" name="address" placeholder="Enter Full Delivery Address" id="enter_address"><?=  $this->session->userdata('address'); ?></textarea>

                     </form>

                  </div>
                  
                  <div class="col-md-12 mb-2 checkout-confirm-final" id="final_things" style="display:flex;justify-content:space-between;">
                     <a href="<?= base_url("terms"); ?>" target="_blank"><span class="kkk" ><b class="text-dark">Things to Know</b></span></a>
                     <?php
                       if(!$this->session->userdata("coupon_discount")){               
                     ?>
                     <a href="#!" data-bs-toggle="modal" data-bs-target="#couponModal">
                         Apply Coupon
                     </a>
                     <?php
                       }else{
                     ?>
                     <a href="<?= base_url("Ford/apply_coupon"); ?>" onclick="return confirm('Are you sure to remove applied coupon ?')">
                        <font color="red">X</font>
                         <?= $this->session->userdata("coupon_name"); ?> 
                         (<?= $this->session->userdata("coupon_discount"); ?>%)
                     </a>
                     <?php
                       }
                     ?>
                  </div>
               </div>
               
               <!-- sanjay added -->
<!-- Modal -->
<div class="modal fade" id="couponModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Apply Coupon</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form method="post" action="<?= base_url("Ford/apply_coupon"); ?>">
          <input type="hidden" name="total_days" value="<?= $total_days; ?>"/>
      <div class="modal-body">
            <div class="form-group">
                <!--<label>Enter Coupon Name</label>-->
                <input type="text" autocomplete="off" id="coupon-text" name="name" placeholder="Enter Coupon Name" class="form-control" required />
            </div>
            
            <style>
                .coupon-list{
                    list-style: none;
                    padding: 0px;
                    margin-top: 15px;
                    display: inline-block;
                }
                .coupon-list li{
                    border: 2px dashed #000000cc;
                    border-radius: 10px;
                    padding: 5px 30px;
                    margin-top: 10px;
                    margin-left: 10px;
                    cursor: pointer;
                    font-weight: 500;
                    font-size: 16px;
                    float: left;
                }
          </style>
           <?php
             $coupon_list = $this->db->get_where("coupon", ["min_days <="=>$total_days, "secret"=>0])->result();       if(count($coupon_list) == 0){
           ?>
           <h6 style="margin-top:10px;opacity:0.6;text-transform:uppercase;">No eligable coupon available for this booking.</h6>
           <?php     
             }   else{                 
           ?>
            <ul class="coupon-list">
            <?php
                 foreach($coupon_list as $c){
            ?>
                
                    <li class="cnames"><?= $c->name; ?></li>
            <?php        
                }
            ?>
            </ul>
            <?php
             }
                 ?>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Apply</button>
      </div>
      </form>
    </div>
  </div>
</div>
               <!-- end.. sanjay added -->
               
               
               
                  
                  <div class="col-md-12 checkout-next-button-final-one">
                  
                     <div>
                         <?php
                            $price = $c->price;
                            $start_date = $_GET["start"];
                            $day = date("l", strtotime($start_date));
                            // $day = "Saturday";
                                      
                            if($day=="Saturday" || $day=="Sunday"){
                                $price = $c->weekend_price;    
                            }
                         ?>
                         
                          <!-- sanjay commented below code 31-03-2022 -->
                          <!--Total Trip Fair -  <b>₹ <?= $price*$mdate; ?></b>-->
                          
                          <!-- sanjay added below code 31-03-2022 -->
                          <?php
                                if($this->session->userdata("coupon_discount")){
                                    $percent = $this->session->userdata("coupon_discount");
                                    $coupon_discount = ($overall_fare*$percent)/100;
                                    ?>
                          Trip Fare -  <b>₹ <?= $overall_fare; ?></b>  <br/>  
                          Discount - ( <font color="green"><b>-₹<?= $coupon_discount; ?></b></font> ) <br/>
                                    <?php
                                    $overall_fare = $overall_fare-$coupon_discount;
                                }          
                          ?>
                          <span>Total Trip Fare-  <b>₹ &nbsp;&nbsp;<?= number_format($overall_fare + $percentAddon); ?></b></span> 
                          

                        <!-- <span class="kkk" style="float:right; cursor: pointer;" data-bs-toggle="modal" data-bs-target="#exampleModal">
                           <i class="fa fa-gift" aria-hidden="true"></i> 
                           <b>Apply coupon</b>
                        </span> -->

                     </div>

                     <?php if($isLessThan_24Hrs == 0){ ?>
                  
                        
                        
                        <?php if($this->session->userdata('user_id') == ''){ ?>

                        <div >
                           <a class="btn btn-block p-2" href="<?= base_url(); ?>Signup">
                              Checkout Summary
                           </a>
                        </div>
    
                      <?php } else { ?>
    
                        <div >
                           <a class="btn btn-block p-2" href="<?= base_url(); ?>Distribute">
                              Checkout Summary
                           </a>
                        </div>
    
                      <?php } ?>

                     <?php } else{ ?>

                        <div >
                           <a class="btn btn-block btn-outline-dark" href="<?= $_SERVER["HTTP_REFERER"]; ?>">
                              Go Back & Select At least 24 Hours Duration
                           </a>
                        </div>

                     <?php } ?>

                  </div>

                  
               </div>

            </div>

         <?php } ?>

         </div>

      </div>
   </div>
</main>

<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
   
    <div class="modal-content">
   
      <!-- <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Apply Coupon</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div> -->
      
      <form id="apply_coupon">
         
         <div class="modal-body">
           <input type="text" name="coupon" class="form-control p-2" placeholder="Enter Coupon Code">
         </div>
      
         <div class="modal-footer">
           <button type="button" class="btn btn-primary">Apply Coupon</button>
           <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
         </div>

      </form>
   
    </div>
  </div>
</div>


<script type="text/javascript">
   $(document).on("click", ".cnames", function(){
       const cnames = $(this).text();
       $(".cnames").css({"background-color": "#fff"});
       $(this).css({"background-color": "lightyellow"});
       $("#coupon-text").val(cnames);
   });
    
   $('#check1').click(function(e){

      var check = $(this);
      var user_id = $('#user_id').val();

      if (check.is(":checked")==true){ 
            if(user_id != ''){
               $('#address').css('display','block');
               $.ajax({
                  url: '<?= base_url(); ?>Book/set_check'
               });
            }else{
                alert('Dear user please register or login into your Account');
               window.location.href="Signup?home_delivery=yes";
            }
       }else{
         $('#address').css('display','none');
         $.ajax({
           url: '<?= base_url(); ?>Book/unset_user_address'
         });
       }

   });

   $('#enter_address').keyup(function(e){

      var address = $(this).val();
      var check = $('#check1');
      var user_id = $('#user_id').val();

       if ($('#check1').is(":checked")==true){ 
           check_address = 1;
           
           $.ajax({
               url: '<?= base_url(); ?>Book/set_user_address',
               method:'post',
               dataType: 'html',
               data: {'address': address, 'check': check_address, 'user_id': user_id},
               success:function(response){
                  console.log(response);
               }
           });

       }else{
         check_address = 0;
           alert(check_address);
       }

   });


</script>